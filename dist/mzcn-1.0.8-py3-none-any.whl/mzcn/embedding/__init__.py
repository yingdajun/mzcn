from .embedding import Embedding
from .embedding import load_from_file
