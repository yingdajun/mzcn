"""Define Keras tensor type."""
import typing

TensorType = typing.Any
